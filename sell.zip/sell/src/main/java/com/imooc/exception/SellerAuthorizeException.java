package com.imooc.exception;

/**
 * Created by 廖师兄
 * 2017-07-30 17:41
 */
public class SellerAuthorizeException extends RuntimeException {
}
